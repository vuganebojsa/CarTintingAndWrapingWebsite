firebaseUrlGallery = "https://vuga-tuning-centar-default-rtdb.europe-west1.firebasedatabase.app/Galerija/.json";

let addForma = document.getElementById('editForm');

let newPicture = {};

addForma.addEventListener('submit', function(e){
   
	e.preventDefault();
	let requestGallery = new XMLHttpRequest();
	requestGallery.onreadystatechange = function(){
	if(this.readyState == 4){
		if(this.status == 200){
			let pictures = JSON.parse(this.responseText);
			let Naziv_Rada = document.getElementById('nazivRada').value.trim();
			let Slike_Rada = document.getElementById('slikaRada').value.trim();
            let Tip = document.getElementById('tip').value.trim();
			let tacniPodaci = false;
            
			if(nazivRada == ""){
				alert("Niste uneli naziv rada.");
			}
			else if(slikaRada == ""){
				alert("Niste uneli sliku rada");
			}
			else{
                newPicture.Naziv_Rada = Naziv_Rada;
                newPicture.Slike_Rada = Slike_Rada;
                newPicture.Tip = Tip;
                let noviRedniBroj = 1;
				for(picture in pictures){
                    noviRedniBroj++;
                    tacniPodaci = true;
                    
				}
				if(tacniPodaci){
					// post konekcija i salje na bazu
                    let nazivNovogRada = "Rad" + noviRedniBroj;
                    let putRequest = new XMLHttpRequest();

                    putRequest.onreadystatechange = function(e){
                        if(this.readyState == 4){
                            if(this.status == 200){
                                alert("Uspesno ste uneli novu sliku u galeriju.");
                            }
                            else{
                                alert("Doslo je do greske.");
                            }
                        }
                    }
                    putRequest.open('PUT', "https://vuga-tuning-centar-default-rtdb.europe-west1.firebasedatabase.app/Galerija/".concat(nazivNovogRada, '.json'));
                    putRequest.send(JSON.stringify(newPicture));
				}
				else{
					alert("Neispravni podaci.");
				}
			}

		}
		else{
			alert("Doslo je do greske.");
		}
	}

	}
	requestGallery.open('GET', firebaseUrlGallery);
	requestGallery.send();

});
