firebaseUrl = "https://vuga-tuning-centar-default-rtdb.europe-west1.firebasedatabase.app/Korisnici/.json";



let loginForma = document.getElementById('loginForma');

loginForma.addEventListener('submit', function(e){
   
	e.preventDefault();
	let request = new XMLHttpRequest();

	request.onreadystatechange = function(){
	if(this.readyState == 4){
		if(this.status == 200){
			let users = JSON.parse(this.responseText);
		
			let korisnickoIme = document.getElementById('korisnickoImeLogin').value.trim();
			let lozinka = document.getElementById('lozinkaLogin').value.trim();
			let tacniPodaci = false;
         
			if(korisnickoIme == ""){
				alert("Niste uneli korisnicko ime.");
			}
			else if(lozinka == ""){
				alert("Niste uneli lozinku");
			}
			else{
				for(user in users){
					if((korisnickoIme == users[user]["Username"] || korisnickoIme == users[user]["Email"]) && lozinka == users[user]["Password"]){
						tacniPodaci = true;
						break;
					}
				}
				if(tacniPodaci){
					alert("Uspesno ste se ulogovali!");
					window.location.href = "mainPage.html";
				}
				else{
					alert("Neispravni podaci.");
				}
			}

		}
		else{
			alert("Doslo je do greske.");
		}
	}

	}
	request.open('GET', firebaseUrl);
	request.send();

});